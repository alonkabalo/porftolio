const images = ["anchor.jpg", "banzai.jpg", "bells.jpg", "boilers.jpg", "cangu.jpg", "chickens.jpg", "jaws.jpg", "jeffreys.jpg", "lacanau.jpg", "main-point.jpg", "midigama.jpg", "nazare.jpg", "padang.jpg", "peniche.jpg", "puerto.jpg", "santa.jpg", "skeleton.jpg", "snapper.jpg", "teahupoo.jpg", "waikiki.jpg",];
let currentImage = -1;
let myInterval;


function nextImage() {
    currentImage++;

    if (currentImage >= images.length) {
        currentImage = 0;
    }

    const img = document.querySelector('#gallery img');
    img.src = `images/${images[currentImage]}`;
}

function prevImage() {
    currentImage--;

    if (currentImage < 0) {
        currentImage = images.length - 1;
    }

    const img = document.querySelector('#gallery img');
    img.src = `images/${images[currentImage]}`;
}

window.addEventListener('keydown', ev => {
    if (ev.key == 'ArrowRight') {
        prevImage();
    } else if (ev.key == 'ArrowLeft') {
        nextImage();
    }
});

function startAuto() {
    stopAuto();
    myInterval = setInterval(nextImage, 5 * 1000);
}

function stopAuto() {
    clearInterval(myInterval);
}

function openModal() {
    const modal = document.getElementById("modal");
    modal.style.display = "block";
    setTimeout(() => modal.classList.add("show"), 10);  
    document.getElementById("desc").innerText = descriptions[currentImage];
    stopAuto();
}

function closeModal() {
    const modal = document.getElementById("modal");
    modal.classList.remove("show");
    setTimeout(() => modal.style.display = "none", 300);  
    startAuto();  
}

nextImage();
startAuto();  
